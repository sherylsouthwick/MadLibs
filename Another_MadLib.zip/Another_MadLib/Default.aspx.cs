﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

class MyClass
{
    private string[] MyArray = new string[11];
    public string this[int index]
    {
        get { return MyArray[index]; }
        set { MyArray[index] = value; }
    }
}
class Eleven <A,B,C,D,E,F,G,H,I,J,K>
{
    public A First { get; set; }
    public B Second { get; set; }
    public C Third { get; set; }
    public D Fourth { get; set; }
    public E Fifth { get; set; }
    public F Sixth { get; set; }
    public G Seventh { get; set; }
    public H Eighth { get; set; }
    public I Ninth { get; set; }
    public J Tenth { get; set; }
    public K Eleventh { get; set; }
    public override string ToString()
    {
        string story= "\nMy Dogs\r\n"
            + "My " + First + "s are the smartest dogs ever. One of them is named " + Second
            + ", and is a " + Third
            + " Retriever. He is " + Fourth
           + " years old. The other one, " + Fifth
            + ", is a " + Sixth
            + " Terrier, and she is " + Seventh
             + " years old. " + Second
            + " steals our socks, and sometimes he eats them. " + Fifth
            + " eats her own " + Eighth
           + ". Yuck! They both do tricks, like " + Ninth
            + " and roll over and play dead, and " + Tenth
           + ". Even though " + Second
           + " weighs " + Eleventh
           + " pounds, he thinks he is small, and sits on our lap to cuddle."
           + " The best thing about " + Second + " and " + Fifth
           + " is that they love us so much. ";
        return story;
    }
}
public partial class _Default : System.Web.UI.Page
{
    protected void btnWriteStory_Click(object sender, EventArgs e)
    {
        TextBox3.ForeColor = System.Drawing.Color.Black; TextBox6.ForeColor = System.Drawing.Color.Black;
        TextBox10.ForeColor = System.Drawing.Color.Black;
        string[] ThisArray = {TextBox0.Text, TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox4.Text,
            TextBox5.Text, TextBox6.Text, TextBox7.Text, TextBox8.Text,TextBox9.Text,TextBox10.Text };
        MyClass mc = new MyClass();
        for (int i = 0; i < 11; i++)
        {
            mc[i] = ThisArray[i];
        }
        int age1; int age2; int weight;
        if (!int.TryParse(mc[3],out age1))
        {
            TextBox3.Text="Enter a NUMBER."; TextBox3.ForeColor = System.Drawing.Color.Red;
        }
        else if (!int.TryParse(mc[6], out age2))
        {
            TextBox6.Text = "Enter a NUMBER."; TextBox6.ForeColor = System.Drawing.Color.Red;
        }
        else if (!int.TryParse(mc[10], out weight))
        {
            TextBox10.Text = "Enter LARGE NUMBER."; TextBox10.ForeColor = System.Drawing.Color.Red;
        }
        else
        {
            Eleven<string, string, string, int, string, string, int, string,
            string, string, decimal> story = new Eleven<string, string, string, 
            int, string, string, int, string, string, string, decimal>
            {
                First = mc[0],
                Second = UpperFirst (mc[1]),
                Third = UpperFirst(mc[2]),
                Fourth = int.Parse(mc[3]),
                Fifth = UpperFirst(mc[4]),
                Sixth = UpperFirst(mc[5]),
                Seventh = int.Parse(mc[6]),
                Eighth = mc[7],
                Ninth = mc[8],
                Tenth = mc[9],
                Eleventh = decimal.Parse(mc[10])
            };
            textboxStory.Text = story.ToString();

        }

    }
    private string UpperFirst(string text)
    {
        return char.ToUpper(text[0]) +
            ((text.Length > 1) ? text.Substring(1).ToLower() : string.Empty);
    }
}